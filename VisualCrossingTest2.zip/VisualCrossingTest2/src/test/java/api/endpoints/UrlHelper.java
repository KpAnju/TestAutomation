package api.endpoints;

public class UrlHelper {

	
	public static String base_url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/";
	public static String get_timeline_url = base_url+"timeline/{cityname}";
	
}
