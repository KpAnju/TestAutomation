package api.testcases;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import api.endpoints.Endpoints;
import api.pojos.Day;
import api.pojos.WeatherResponse;
import io.restassured.response.Response;
import vc.base.TestBase;

public class GetEndpointTest extends TestBase {
	
	

	public GetEndpointTest() {
		super();
	}

	

	final String DATE_FORMAT_NOW = "yyyy-MM-dd";

	Calendar cal = Calendar.getInstance();
	SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
	String currDate =  sdf.format(cal.getTime());
	

	@Test(priority = 1)
	public void testGetEndpoint() {
		Response response = Endpoints.getTimeline(prop.getProperty("city"),prop.getProperty("token"),prop.getProperty("unitGroup"));
		response.then().log().all();

		Assert.assertEquals(response.getStatusCode(), 200);
		
		ObjectMapper mapper = new ObjectMapper();
		WeatherResponse weatherResp = new WeatherResponse();
		try {
			weatherResp = mapper.readValue(response.getBody().asString(),WeatherResponse.class);
		}
		catch(JsonProcessingException e) {
			e.printStackTrace();
		}
		
		
		ArrayList<Day> list = weatherResp.days;
		
		
		for(Day d:list) {
			if (d.datetime.equals(currDate)) {
			 System.out.println("The returned list has current date temperature");
			 break;
			}
		}
		
	   
		String location = weatherResp.address;
		Double latitude = weatherResp.latitude;
		String latString = latitude.toString();
		
		System.out.println(latitude);
		Double longitude = weatherResp.longitude;
		String longString = longitude.toString();
		
		System.out.println(longitude);
		
		Assert.assertEquals(location, prop.getProperty("city"));
		Assert.assertEquals(latString, prop.getProperty("latitude"));
		Assert.assertEquals(longString, prop.getProperty("longitude"));
		

		

	}

}
